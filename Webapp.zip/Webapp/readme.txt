zuerst in der console in den ordner navigieren und mit
node connect_neo4j.js 
den node.js Server starten -> danach index.html öffnen